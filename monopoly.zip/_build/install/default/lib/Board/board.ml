type property = {
  name : string;
  price : int;
  owner : string option;
}

type board = property array array

let create_property name price = { name; price; owner = None }

let create_board rows cols =
  Array.init rows (fun _ -> Array.init cols (fun _ -> create_property "Empty" 0))

let initialize_board () =
  let board = create_board 11 11 in
  board.(0).(0) <- create_property "Mediterranean Ave" 60;
  board.(0).(1) <- create_property "Baltic Ave" 60;
  board.(0).(2) <- create_property "Oriental Ave" 100;
  board.(0).(3) <- create_property "Vermont Ave" 100;
  board.(0).(4) <- create_property "Connecticut Ave" 120;
  board.(0).(5) <- create_property "St. Charles Place" 140;
  board.(0).(6) <- create_property "States Ave" 140;
  board.(0).(7) <- create_property "Virginia Ave" 160;
  board.(0).(8) <- create_property "St. James Place" 180;
  board.(0).(9) <- create_property "Tennessee Ave" 180;
  board.(0).(10) <- create_property "New York Ave" 200;

  board.(1).(10) <- create_property "Kentucky Ave" 220;
  board.(2).(10) <- create_property "Indiana Ave" 220;
  board.(3).(10) <- create_property "Illinois Ave" 240;
  board.(4).(10) <- create_property "Atlantic Ave" 260;
  board.(5).(10) <- create_property "Ventnor Ave" 260;
  board.(6).(10) <- create_property "Marvin Gardens" 280;
  board.(7).(10) <- create_property "Pacific Ave" 300;
  board.(8).(10) <- create_property "North Carolina Ave" 300;
  board.(9).(10) <- create_property "Pennsylvania Ave" 320;
  board.(10).(10) <- create_property "Park Place" 350;

  board.(10).(9) <- create_property "Boardwalk" 400;
  board.(10).(8) <- create_property "Park Place" 350;
  board.(10).(7) <- create_property "Pennsylvania Ave" 320;
  board.(10).(6) <- create_property "North Carolina Ave" 300;
  board.(10).(5) <- create_property "Pacific Ave" 300;
  board.(10).(4) <- create_property "Marvin Gardens" 280;
  board.(10).(3) <- create_property "Ventnor Ave" 260;
  board.(10).(2) <- create_property "Atlantic Ave" 260;
  board.(10).(1) <- create_property "Illinois Ave" 240;
  board.(10).(0) <- create_property "Indiana Ave" 220;

  board.(9).(0) <- create_property "Kentucky Ave" 220;
  board.(8).(0) <- create_property "New York Ave" 200;
  board.(7).(0) <- create_property "Tennessee Ave" 180;
  board.(6).(0) <- create_property "St. James Place" 180;
  board.(5).(0) <- create_property "Virginia Ave" 160;
  board.(4).(0) <- create_property "States Ave" 140;
  board.(3).(0) <- create_property "St. Charles Place" 140;
  board.(2).(0) <- create_property "Connecticut Ave" 120;
  board.(1).(0) <- create_property "Vermont Ave" 100;
  board.(1).(1) <- create_property "Oriental Ave" 100;
  board

let get_property board row col = board.(row).(col)

let set_property_owner board row col owner =
  let property = get_property board row col in
  board.(row).(col) <- { property with owner = Some owner }
  
  let draw_horizontal_line n =
    for i = 1 to n do
      print_string "----";
      if i < n then
        print_string "+";
    done;
    print_endline ""
  
  let draw_property_box name price =
    let name_length = String.length name in
    let padding = (15 - name_length) / 2 in
    Printf.printf "|%*s%s%*s|$%d|" padding "" name (15 - padding - name_length) "" price
  
  let print_board board =
    let rows = Array.length board in
    let cols = Array.length board.(0) in
    draw_horizontal_line cols;
    for row = 0 to rows - 1 do
      for col = 0 to cols - 1 do
        let property = board.(row).(col) in
        draw_property_box property.name property.price;
        if col = cols - 1 then
          print_string "|";
      done;
      print_endline "";
      if row < rows - 1 then
        draw_horizontal_line cols;
    done

    let () =
    let board = initialize_board () in
    print_board board
